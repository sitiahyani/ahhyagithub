import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: '/', // Atur rute awal
      routes: {
        '/': (context) => ProdukForm(), // Rute ke halaman Form Produk
        '/produklist': (context) =>
            ProdukList(), // Rute ke halaman Daftar Produk
      },
    );
  }
}

// ... (Kode ProdukForm, ProdukList, dan Produk) ...

class ProdukForm extends StatefulWidget {
  @override
  _ProdukFormState createState() => _ProdukFormState();
}

class _ProdukFormState extends State<ProdukForm> {
  final _kodeProdukController = TextEditingController();
  final _namaProdukController = TextEditingController();
  final _hargaProdukController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xffed8869),
        title: Center(
          child: Text(
            "Form Produk",
            style: TextStyle(color: Colors.white),
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _kodeProdukController,
              decoration: InputDecoration(labelText: "Kode Produk"),
            ),
            TextField(
              controller: _namaProdukController,
              decoration: InputDecoration(labelText: "Nama Produk"),
            ),
            TextField(
              controller: _hargaProdukController,
              decoration: InputDecoration(labelText: "Harga"),
            ),
            SizedBox(
              height: 16.0,
            ),
            ElevatedButton(
              onPressed: () {
                // Tambahkan logika simpan di sini
                final kodeProduk = _kodeProdukController.text;
                final namaProduk = _namaProdukController.text;
                final hargaProduk =
                    double.tryParse(_hargaProdukController.text);

                if (kodeProduk.isNotEmpty &&
                    namaProduk.isNotEmpty &&
                    hargaProduk != null) {
                  final produk = Produk(namaProduk, hargaProduk);
                  Navigator.of(context)
                      .pushNamed('/produklist', arguments: produk);
                }
              },
              child: Text('Simpan'),
            ),
          ],
        ),
      ),
    );
  }
}

class ProdukList extends StatefulWidget {
  @override
  _ProdukListState createState() => _ProdukListState();
}

class _ProdukListState extends State<ProdukList> {
  List<Produk> _produkList = [];

  @override
  Widget build(BuildContext context) {
    final produk = ModalRoute.of(context)!.settings.arguments as Produk;

    // Menambahkan produk ke dalam list
    _produkList.add(produk);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xffed8869),
        title: Center(
          child: Text(
            "Daftar Produk",
            style: TextStyle(color: Colors.white),
          ),
        ),
      ),
      body: ListView.builder(
        itemCount: _produkList.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(_produkList[index].nama),
            subtitle: Text('Harga: ${_produkList[index].harga}'),
          );
        },
      ),
    );
  }
}

class Produk {
  final String nama;
  final double harga;

  Produk(this.nama, this.harga);
}
